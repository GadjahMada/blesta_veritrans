<?php
// Gateway name
$lang['NonmerchantDemo.name'] = "Non-merchant Demo";

// Settings
$lang['NonmerchantDemo.user'] = "User";
$lang['NonmerchantDemo.key'] = "Key";
$lang['NonmerchantDemo.key_note'] = "This is a tooltip note.";

// Process form
$lang['NonmerchantDemo.buildprocess.submit'] = "Pay with Non-merchant Demo!";

// Errors
$lang['NonmerchantDemo.!error.key.valid'] = "Key must be 16 characters long.";
?>