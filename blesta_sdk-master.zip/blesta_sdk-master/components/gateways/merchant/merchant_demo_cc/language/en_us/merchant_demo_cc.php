<?php
// Gateway name
$lang['MerchantDemoCc.name'] = "Merchant Demo CC";

// Settings
$lang['MerchantDemoCc.user'] = "User";
$lang['MerchantDemoCc.key'] = "Key";
$lang['MerchantDemoCc.key_note'] = "This is a tooltip note.";

// Errors
$lang['MerchantDemoCc.!error.key.valid'] = "Key must be 16 characters long.";
?>